from pydantic import BaseModel, Field
from typing import List


# ============================================================
# Chat Models
# ============================================================

class ChatRequest(BaseModel):
    query: str = Field(
        ...,
        min_length=1,
        max_length=500,
        description="User question",
    )


class Source(BaseModel):
    document: str
    page: int


class ChatResponse(BaseModel):
    answer: str
    sources: List[Source] = []
    related_questions: List[str] = []


# ============================================================
# Upload Models
# ============================================================

class UploadResponse(BaseModel):
    filename: str
    file_type: str
    message: str


# ============================================================
# Ingestion Models
# ============================================================

class IngestionResponse(BaseModel):
    filename: str
    file_type: str
    chunks: int
    status: str


# ============================================================
# OCR Models
# ============================================================

class OCRResponse(BaseModel):
    extracted_text: str


# ============================================================
# Vision Models
# ============================================================

class VisionResponse(BaseModel):
    analysis: str


# ============================================================
# Combined Medical Analysis
# ============================================================

class MedicalAnalysisResponse(BaseModel):
    filename: str
    file_type: str
    ocr_text: str
    vision_analysis: str


# ============================================================
# Health Check
# ============================================================

class HealthResponse(BaseModel):
    status: str


# ============================================================
# Error Response
# ============================================================

class ErrorResponse(BaseModel):
    detail: str