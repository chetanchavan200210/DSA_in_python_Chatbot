from pathlib import Path

from docling.document_converter import DocumentConverter

# --------------------------------------------------
# Singleton Converter
# --------------------------------------------------

_converter = None


def get_converter() -> DocumentConverter:
    """
    Load the Docling converter only once.
    """

    global _converter

    if _converter is None:
        print("Loading Docling...")
        _converter = DocumentConverter()

    return _converter


# --------------------------------------------------
# Extract Text from PDF
# --------------------------------------------------

def extract_text(file_path: str) -> str:
    """
    Extract text from a PDF using Docling.

    Parameters
    ----------
    file_path : str
        Path to the PDF.

    Returns
    -------
    str
        Markdown representation of the document.
    """

    if not Path(file_path).exists():
        raise FileNotFoundError(
            f"File not found: {file_path}"
        )

    converter = get_converter()

    try:

        print(f"\nParsing PDF: {Path(file_path).name}")

        result = converter.convert(file_path)

        text = result.document.export_to_markdown()

        print(f"Characters extracted: {len(text)}")

        return text.strip()

    except Exception as e:

        raise RuntimeError(
            f"Docling failed to parse '{file_path}': {e}"
        )